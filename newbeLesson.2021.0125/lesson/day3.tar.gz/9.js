var GameArray = new Array();
GameArray[0] = new Array("2010-01-03");
GameArray[1] = new Array("2010-01-04");
GameArray[2] = new Array("2010-01-05");
GameArray[3] = new Array("2010-01-06");

function init(){
	
		var div_model = document.getElementById("div_model");
		var tpl = new fastTemplate();
		tpl.init(div_model);
		
		for(var j=0; j<GameArray.length; j++){
			
				//加入動態區塊，名稱自定義
				tpl.addBlock("aaa");
				
				tpl.replace("*ID*", j);
				tpl.replace("*DATETIME*", GameArray[j]);
		}
			
		var div_show = document.getElementById("div_show");
		
		//最後parse畫面
		div_show.innerHTML = tpl.fastPrint();	

}