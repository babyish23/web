function exFun(){
		alert("hello");
}